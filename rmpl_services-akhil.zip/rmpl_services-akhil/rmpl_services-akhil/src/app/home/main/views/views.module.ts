import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServicesComponent } from './services/services.component';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../../../material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServiceInfoComponent } from './service-info/service-info.component';



@NgModule({
  declarations: [ServicesComponent, ServiceInfoComponent],

  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild([
      {
        path: 'services',
        component: ServicesComponent,

      }, {
        path: 'services-info',
        component: ServiceInfoComponent,

      },


      {
        path: '', redirectTo: 'services', pathMatch: 'full'
      }
    ])
  ],

})
export class ViewsModule { }
