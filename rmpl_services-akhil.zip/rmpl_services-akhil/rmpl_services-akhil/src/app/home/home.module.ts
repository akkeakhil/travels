import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MainComponent } from './main/main.component';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [HeaderComponent, FooterComponent, MainComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
  

    RouterModule.forChild([
      {
        path: 'home',
        component: MainComponent,
        children: [
          {
            path: '',
            loadChildren: () => import('./main/views/views.module').then(m => m.ViewsModule)
          }
        ]

      }
      , {
        path: "**",
        redirectTo: 'home',
        pathMatch: "full"
      }
    ])
  ]
})
export class HomeModule { }
